export class Song {
    id: number;
    title: string;
    album: string;
    author: string;
    style: string;
    year: string;
    duration: string;
    description: string;
    picture: string;
  }